package io.rhythmknights.coretags.component.command;

import io.rhythmknights.coreframework.component.utility.TextUtility;
import io.rhythmknights.coretags.CoreTags;
import io.rhythmknights.coretags.component.data.PlayerDataModule;
import io.rhythmknights.coretags.component.modal.TagModal;
import java.util.Arrays;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Objects;
import java.util.UUID;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.luckperms.api.LuckPerms;
import net.luckperms.api.model.group.Group;
import net.luckperms.api.node.Node;
import org.bukkit.Bukkit;
import org.bukkit.OfflinePlayer;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.PluginCommand;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

public final class CommandModule implements CommandExecutor, TabCompleter {
   private final CoreTags plugin;
   private final TagModal tagModal;
   private final PlayerDataModule dataManager;
   private final LuckPerms lp;
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().hexColors().build();
   private final MiniMessage miniMessage = MiniMessage.miniMessage();

   public CommandModule(CoreTags plugin) {
      this.plugin = plugin;
      this.tagModal = plugin.tags();
      this.dataManager = plugin.playerData();
      this.lp = plugin.luckPerms().api();
      PluginCommand cmd = (PluginCommand)Objects.requireNonNull(plugin.getCommand("coretags"), "coretags command missing from plugin.yml");
      cmd.setExecutor(this);
      cmd.setTabCompleter(this);
   }

   public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
      if (args.length == 0) {
         if (sender instanceof Player) {
            Player p = (Player)sender;
            this.plugin.modalProcessor().openCategoryGui(p);
         } else {
            sender.sendMessage("/coretags reload | unlock | lock");
         }

         return true;
      } else {
         String var5 = args[0].toLowerCase(Locale.ROOT);
         byte var6 = -1;
         switch(var5.hashCode()) {
         case -934641255:
            if (var5.equals("reload")) {
               var6 = 0;
            }
            break;
         case -840442044:
            if (var5.equals("unlock")) {
               var6 = 1;
            }
            break;
         case 3327275:
            if (var5.equals("lock")) {
               var6 = 2;
            }
         }

         switch(var6) {
         case 0:
            if (!sender.hasPermission("coretags.reload")) {
               sender.sendMessage("§cNo permission.");
               return true;
            }

            this.plugin.reloadEverything();
            this.plugin.sendReloadMessage(sender);
            return true;
         case 1:
         case 2:
            boolean grant = args[0].equalsIgnoreCase("unlock");
            if (!sender.hasPermission("coretags.admin.*")) {
               sender.sendMessage("§cNo permission.");
               return true;
            }

            return this.handleGrantRevoke(sender, args, grant);
         default:
            sender.sendMessage("§cUnknown sub-command.");
            return true;
         }
      }
   }

   private boolean handleGrantRevoke(CommandSender sender, String[] a, boolean grant) {
      if (a.length < 4) {
         sender.sendMessage("§cUsage: /coretags " + (grant ? "unlock" : "lock") + " <tag> <player|group> <name|*>");
         return true;
      } else {
         String tagId = a[1].toLowerCase(Locale.ROOT);
         TagModal.Tag tag = (TagModal.Tag)this.tagModal.byId(tagId).orElse((Object)null);
         if (tag == null) {
            sender.sendMessage("§cTag '" + tagId + "' not found.");
            return true;
         } else {
            String scope = a[2].toLowerCase(Locale.ROOT);
            String target = a[3];
            if (scope.equals("player")) {
               if (target.equals("*")) {
                  Iterator onlinePlayersIterator = Bukkit.getOnlinePlayers().iterator();

                  while(onlinePlayersIterator.hasNext()) {
                     Player p = (Player)onlinePlayersIterator.next();
                     this.toggleForPlayer(p.getUniqueId(), tagId, grant, sender);
                  }

                  sender.sendMessage("§aUpdated all online players.");
               } else {
                  OfflinePlayer off = Bukkit.getOfflinePlayer(target);
                  if (!off.hasPlayedBefore() && !off.isOnline()) {
                     sender.sendMessage("§cUnknown player.");
                     return true;
                  }

                  this.toggleForPlayer(off.getUniqueId(), tagId, grant, sender);
                  sender.sendMessage("§aUpdated " + off.getName() + ".");
               }
            } else if (scope.equals("group")) {
               if (this.lp == null) {
                  sender.sendMessage("§cLuckPerms not found.");
                  return true;
               }

               Group g = this.lp.getGroupManager().getGroup(target);
               if (g == null) {
                  sender.sendMessage("§cGroup not found.");
                  return true;
               }

               String node = "coretags.tag." + tagId;
               if (grant) {
                  g.data().add(Node.builder(node).value(true).build());
               } else {
                  g.data().remove(Node.builder(node).build());
               }

               sender.sendMessage("§aGroup '" + g.getName() + "' updated.");
            } else {
               sender.sendMessage("§cScope must be player or group.");
            }

            return true;
         }
      }
   }

   private void toggleForPlayer(UUID uuid, String tagId, boolean grant, CommandSender sender) {
      OfflinePlayer off = Bukkit.getOfflinePlayer(uuid);
      TagModal.Tag tag = (TagModal.Tag)this.tagModal.byId(tagId).orElse((Object)null);
      Object tagNameComponent;
      if (tag != null) {
         tagNameComponent = tag.name();
      } else {
         tagNameComponent = Component.text(tagId);
      }

      String playerName = off.getName() != null ? off.getName() : "Unknown";
      String playerUnlockMessage;
      String tagName;
      Component parsedPlayerUnlockMessage;
      String consoleUnlockMessage;
      Component parsedConsoleUnlockMessage;
      if (grant) {
         this.dataManager.unlockTag(uuid, tagId);
         playerUnlockMessage = this.plugin.getConfig().getString("settings.messages.tag-unlocked", "<green>{tag}</green> <gray>has been unlocked.</gray>");
         tagName = "";
         if (tagNameComponent instanceof TextComponent) {
            tagName = ((TextComponent)tagNameComponent).content().trim();
         } else {
            tagName = tagId;
         }

         playerUnlockMessage = playerUnlockMessage.replace("{tag}", tagName);
         parsedPlayerUnlockMessage = this.miniMessage.deserialize(playerUnlockMessage);
         if (off.isOnline() && off.getPlayer() != null) {
            this.plugin.adventure().sender(off.getPlayer()).sendMessage(parsedPlayerUnlockMessage);
         }

         consoleUnlockMessage = this.plugin.getConfig().getString("settings.messages.tag-authorize", "<gold>{tag}</gold> <gray>tag</gray> <green>unlocked</green> <gray>for</gray> <blue>{player}</blue>.");
         consoleUnlockMessage = consoleUnlockMessage.replace("{tag}", tagName).replace("{player}", playerName);
         parsedConsoleUnlockMessage = this.miniMessage.deserialize(consoleUnlockMessage);
         this.plugin.adventure().sender(sender).sendMessage(parsedConsoleUnlockMessage);
      } else {
         this.dataManager.lockTag(uuid, tagId);
         playerUnlockMessage = this.plugin.getConfig().getString("settings.messages.tag-locked", "<red>{tag}</red> <gray>has been locked.</gray>");
         tagName = "";
         if (tagNameComponent instanceof TextComponent) {
            tagName = ((TextComponent)tagNameComponent).content().trim();
         } else {
            tagName = tagId;
         }

         playerUnlockMessage = playerUnlockMessage.replace("{tag}", tagName);
         parsedPlayerUnlockMessage = this.miniMessage.deserialize(playerUnlockMessage);
         if (off.isOnline() && off.getPlayer() != null) {
            this.plugin.adventure().sender(off.getPlayer()).sendMessage(parsedPlayerUnlockMessage);
         }

         consoleUnlockMessage = this.plugin.getConfig().getString("settings.messages.tag-revoke", "<gold>{tag}</gold> <gray>tag</gray> <red>locked</red> <gray>for</gray> <blue>{player}</blue>.");
         consoleUnlockMessage = consoleUnlockMessage.replace("{tag}", tagName).replace("{player}", playerName);
         parsedConsoleUnlockMessage = this.miniMessage.deserialize(consoleUnlockMessage);
         this.plugin.adventure().sender(sender).sendMessage(parsedConsoleUnlockMessage);
      }

   }

   public List<String> onTabComplete(CommandSender s, Command c, String a, String[] args) {
      switch(args.length) {
      case 1:
         return this.filter(args[0], List.of("reload", "unlock", "lock"));
      case 2:
         if (args[0].equalsIgnoreCase("unlock") || args[0].equalsIgnoreCase("lock")) {
            return this.filter(args[1], this.tagModal.all().stream().map(TagModal.Tag::id).toList());
         }
         break;
      case 3:
         return this.filter(args[2], List.of("player", "group"));
      case 4:
         if (args[2].equalsIgnoreCase("player")) {
            return this.filter(args[3], this.playerSuggestions());
         }

         if (args[2].equalsIgnoreCase("group") && this.lp != null) {
            return this.filter(args[3], this.lp.getGroupManager().getLoadedGroups().stream().map(Group::getName).toList());
         }
      }

      return List.of();
   }

   private List<String> playerSuggestions() {
      return (List)Arrays.stream(Bukkit.getOfflinePlayers()).map(OfflinePlayer::getName).filter(Objects::nonNull).collect(Collectors.toList());
   }

   private List<String> filter(String arg, List<String> base) {
      String low = arg.toLowerCase(Locale.ROOT);
      return base.stream().filter((s) -> {
         return s.toLowerCase(Locale.ROOT).startsWith(low);
      }).sorted().toList();
   }
}