package io.rhythmknights.coretags.component.modal;

import io.rhythmknights.coreapi.component.modal.Modal;
import io.rhythmknights.coreapi.component.modal.PaginatedModal;
import io.rhythmknights.coreapi.component.modal.builder.item.ItemBuilder;
import io.rhythmknights.coreapi.component.modal.ModalItem;
import io.rhythmknights.coreapi.component.module.PaginationRegion;
import io.rhythmknights.coreframework.component.utility.TextUtility;
import io.rhythmknights.coretags.CoreTags;
import io.rhythmknights.coretags.component.data.ConfigModule;
import io.rhythmknights.coretags.component.data.PlayerDataModule;
import io.rhythmknights.coretags.component.hook.VaultHook;
import java.io.File;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.UUID;
import java.util.Map.Entry;
import java.util.stream.Collectors;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.TextComponent;
import net.kyori.adventure.text.format.TextDecoration;
import net.kyori.adventure.text.minimessage.MiniMessage;
import net.kyori.adventure.text.serializer.legacy.LegacyComponentSerializer;
import net.kyori.adventure.text.serializer.plain.PlainTextComponentSerializer;
import org.bukkit.Bukkit;
import org.bukkit.Material;
import org.bukkit.configuration.ConfigurationSection;
import org.bukkit.configuration.InvalidConfigurationException;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;
import org.bukkit.enchantments.Enchantment;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.ClickType;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.event.inventory.InventoryCloseEvent;
import org.bukkit.event.inventory.InventoryDragEvent;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemFlag;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

public final class ModalProcessor implements Listener {
   private final CoreTags plugin;
   private final ConfigModule cfg;
   private final CategoryModal cats;
   private final TagModal tags;
   private final PlayerDataModule data;
   private final VaultHook eco;
   private final FileConfiguration catCfg;
   private final FileConfiguration tagCfg;
   private final String defaultView;
   private final boolean swapGlobal;
   private final ConfigModule.CloseCmd closeCfg;
   private final Map<UUID, ModalProcessor.GuiSession> open = new HashMap();
   private ModalProcessor.Btn catBtn;
   private ModalProcessor.Btn favBtn;
   private ModalProcessor.Btn prevBtn;
   private ModalProcessor.Btn nextBtn;
   private ModalProcessor.Btn resetBtn;
   private ModalProcessor.Btn backBtn;
   private ModalProcessor.Btn closeBtn;
   private ModalProcessor.Btn activeBtn;
   private ModalProcessor.Btn colorSortBtn;
   private boolean colorSwitchMaterial;
   private boolean categorySwitchMaterial;
   private static final LegacyComponentSerializer LEGACY = LegacyComponentSerializer.builder().character('&').hexColors().build();
   private static final PlainTextComponentSerializer PLAIN = PlainTextComponentSerializer.plainText();
   private static final MiniMessage MINI = MiniMessage.miniMessage();
   private static final List<String> COLORS = List.of(new String[]{"ALL", "MULTI", "RED", "ORANGE", "YELLOW", "GREEN", "BLUE", "PURPLE", "PINK", "BROWN", "GRAY", "BLACK", "WHITE"});

   public ModalProcessor(CoreTags pl) {
      this.plugin = pl;
      this.cfg = pl.configs();
      this.cats = pl.categories();
      this.tags = pl.tags();
      this.data = pl.playerData();
      this.eco = pl.economy();
      this.defaultView = this.plugin.getConfig().getString("settings.system.default-view", "category").toLowerCase(Locale.ROOT);
      this.swapGlobal = this.plugin.getConfig().getBoolean("settings.system.close-button-swap", true);
      this.closeCfg = this.cfg.closeCmd();
      File catFile = new File(this.plugin.getDataFolder(), "components/categories.yml");
      this.catCfg = YamlConfiguration.loadConfiguration(catFile);
      File tagFile = new File(this.plugin.getDataFolder(), "components/tags.yml");
      this.tagCfg = YamlConfiguration.loadConfiguration(tagFile);
      this.loadButtonMeta();
      Bukkit.getPluginManager().registerEvents(this, this.plugin);
   }

   private void loadButtonMeta() {
      String base = "settings.gui.layout.items.";
      this.catBtn = new ModalProcessor.Btn(this.mat("category-sort-button-material"), this.slot(base + "category-sort-button-slot"));
      this.favBtn = new ModalProcessor.Btn(this.mat("favorite-sort-button-material"), this.slot(base + "favorite-sort-button-slot"));
      this.prevBtn = new ModalProcessor.Btn(this.mat("last-page-button-material"), this.slot(base + "last-page-button-slot"));
      this.nextBtn = new ModalProcessor.Btn(this.mat("next-page-button-material"), this.slot(base + "next-page-button-slot"));
      this.resetBtn = new ModalProcessor.Btn(this.mat("reset-button-material"), this.slot(base + "reset-button-slot-tags"));
      this.backBtn = new ModalProcessor.Btn(this.mat("back-button-material"), this.slot(base + "back-button-slot-tags"));
      this.closeBtn = new ModalProcessor.Btn(this.mat("close-button-material"), this.slot(base + "close-button-slot-tags"));
      this.activeBtn = new ModalProcessor.Btn(this.mat("active-tag-material"), this.slot(base + "active-tag-item-slot-tags"));
      this.colorSortBtn = new ModalProcessor.Btn(this.mat("color-sort-button-material"), this.slot(base + "color-sort-button-slot"));
      this.colorSwitchMaterial = this.plugin.getConfig().getBoolean("settings.gui.layout.materials.color-sort-button-material.material-switch", false);
      this.categorySwitchMaterial = this.plugin.getConfig().getBoolean("settings.gui.layout.materials.category-sort-button-material.material-switch", false);
      this.plugin.getLogger().info("[CoreTags][Debug] colorSwitchMaterial=" + this.colorSwitchMaterial);
      this.plugin.getLogger().info("[CoreTags][Debug] categorySwitchMaterial=" + this.categorySwitchMaterial);
      if (!this.colorSwitchMaterial) {
         this.colorSortBtn = new ModalProcessor.Btn(this.mat("color-sort-button-material"), this.slot(base + "color-sort-button-slot"));
      } else {
         this.colorSortBtn = new ModalProcessor.Btn(Material.BARRIER, this.slot(base + "color-sort-button-slot"));
      }

   }

   public void reloadFileConfigs() {
      this.plugin.reloadConfig();
      File catFile = new File(this.plugin.getDataFolder(), "components/categories.yml");

      try {
         ((YamlConfiguration)this.catCfg).load(catFile);
      } catch (InvalidConfigurationException | IOException var5) {
         this.plugin.getLogger().severe("Could not reload components/categories.yml: " + var5.getMessage());
      }

      File tagFile = new File(this.plugin.getDataFolder(), "components/tags.yml");

      try {
         ((YamlConfiguration)this.tagCfg).load(tagFile);
      } catch (InvalidConfigurationException | IOException var4) {
         this.plugin.getLogger().severe("Could not reload components/tags.yml: " + var4.getMessage());
      }

      this.loadButtonMeta();
   }

   public void refreshAll() {
      Iterator var1 = this.open.keySet().iterator();

      while(var1.hasNext()) {
         UUID id = (UUID)var1.next();
         Player p = Bukkit.getPlayer(id);
         if (p != null) {
            p.closeInventory();
         }
      }

      this.open.clear();
   }

   private Component colorButtonTitle(String colorKey) {
      String path = "settings.system.colors." + colorKey.toLowerCase(Locale.ROOT) + ".text";
      String raw = this.plugin.getConfig().getString(path, colorKey);
      return MINI.deserialize(raw);
   }

   public void openCategoryGui(Player p) {
      int rows = this.plugin.getConfig().getInt("settings.gui.category-menu.rows", 4);
      String titlePat = this.plugin.getConfig().getString("settings.gui.layout.titles.category-gui-name", "&8Tags | Categories");
      Component title = LEGACY.deserialize(titlePat);
      
      PaginatedModal modal = Modal.paginated()
         .title(title)
         .rows(rows)
         .build();

      this.fillEmptySlots(modal.getInventory(), "category-gui");
      
      this.cats.all().stream().filter((c) -> {
         return p.hasPermission(c.permission());
      }).sorted(Comparator.comparingInt(CategoryModal.TagCategory::slot)).forEach((c) -> {
         LegacyComponentSerializer var10001x = LEGACY;
         LegacyComponentSerializer var10000 = LEGACY;
         String var10001 = var10001x.serialize(c.displayName());
         Component name = var10000.deserialize("&r&f" + var10001).decoration(TextDecoration.ITALIC, false);
         
         ModalItem categoryItem = ItemBuilder.from(c.icon())
            .name(name)
            .lore(c.lore())
            .asModalItem(event -> {
               this.openTagsGui(p, c.key(), 0);
            });
         
         modal.setItem(c.slot(), categoryItem);
      });
      
      this.addCategoryNavigationButtons(modal, p);
      modal.open(p);
      
      String cfgSort = this.plugin.getConfig().getString("settings.system.favorites-sort", "UNSORTED").toUpperCase(Locale.ROOT);
      ModalProcessor.Sort defaultSort;
      try {
         defaultSort = ModalProcessor.Sort.valueOf(cfgSort);
      } catch (IllegalArgumentException var15) {
         defaultSort = ModalProcessor.Sort.UNSORTED;
      }

      this.open.put(p.getUniqueId(), new ModalProcessor.GuiSession(ModalProcessor.GuiType.CATEGORY, 0, "ALL", defaultSort, "ALL"));
   }

   public void openTagsGui(Player p, String categoryFilter, int page) {
      ModalProcessor.GuiSession s = (ModalProcessor.GuiSession)this.open.computeIfAbsent(p.getUniqueId(), (u) -> {
         String cfgSort = this.plugin.getConfig().getString("settings.system.favorites-sort", "UNSORTED").toUpperCase(Locale.ROOT);

         ModalProcessor.Sort defaultSort;
         try {
            defaultSort = ModalProcessor.Sort.valueOf(cfgSort);
         } catch (IllegalArgumentException var5) {
            defaultSort = ModalProcessor.Sort.UNSORTED;
         }

         return new ModalProcessor.GuiSession(ModalProcessor.GuiType.TAGS, 0, "ALL", defaultSort, "ALL");
      });
      s.type = ModalProcessor.GuiType.TAGS;
      if (categoryFilter != null) {
         s.filter = categoryFilter;
      }

      if (page != -999) {
         s.page = page;
      }

      List<TagModal.Tag> src = this.applyFilterAndSort(p, s);
      List<Integer> slots = this.cfg.guiSlots();
      int perPage = slots.size();
      int maxPage = Math.max(0, (src.size() - 1) / perPage);
      s.page = Math.min(Math.max(0, s.page), maxPage);
      int rows = this.plugin.getConfig().getInt("settings.gui.tags-menu.rows", 6);
      String pattern = this.plugin.getConfig().getString("settings.gui.layout.titles.tags-gui-name", "&8Tags | {category} &7({currentpage}/{totalpages})");
      String filterName = this.catCfg.getString("settings.system.category-sort.filters." + s.filter.toLowerCase(Locale.ROOT) + ".name", s.filter);
      String titleRaw = pattern.replace("{category}", filterName).replace("{currentpage}", String.valueOf(s.page + 1)).replace("{totalpages}", String.valueOf(maxPage + 1));
      
      PaginationRegion region = PaginationRegion.fromSlots(slots);
      
      PaginatedModal modal = Modal.paginated()
         .title(LEGACY.deserialize(titleRaw))
         .rows(rows)
         .paginationRegion(region)
         .build();

      this.fillEmptySlots(modal.getInventory(), "tags-gui");
      
      int base = s.page * perPage;
      for(int i = 0; i < perPage && base + i < src.size(); ++i) {
         ModalItem tagItem = this.buildTagItem(p, (TagModal.Tag)src.get(base + i));
         modal.addItem(tagItem);
      }

      this.addTagsNavigationButtons(modal, p, s);
      modal.open(p, s.page + 1);

      this.open.put(p.getUniqueId(), s);
   }

   private void addCategoryNavigationButtons(PaginatedModal modal, Player player) {
      int resetSlotCat = this.plugin.getConfig().getInt("settings.gui.layout.items.reset-button-slot-category", -1);
      if (resetSlotCat >= 0) {
         ModalItem resetButton = ItemBuilder.from(Material.RED_DYE)
            .name(this.buildNavButtonTitle("reset-button", Map.of()))
            .asModalItem(event -> {
               Player p = (Player) event.getWhoClicked();
               this.data.setActive(p.getUniqueId(), "none");
               String message = this.plugin.getConfig().getString("settings.messages.tag-reset", "");
               Component parsedMessage = TextUtility.parse(message);
               this.plugin.adventure().sender(p).sendMessage(parsedMessage);
               
               Bukkit.getScheduler().runTask(this.plugin, () -> {
                  this.openCategoryGui(p);
               });
            });
         modal.setItem(resetSlotCat, resetButton);
      }

      int activeSlotCat = this.plugin.getConfig().getInt("settings.gui.layout.items.active-tag-item-slot-category", -1);
      String activeId = this.data.get(player.getUniqueId()).active;
      String activeName = activeId != null && !activeId.equalsIgnoreCase("none") && !this.tags.byId(activeId).isEmpty() ? LEGACY.serialize(((TagModal.Tag)this.tags.byId(activeId).get()).name()) : this.tagCfg.getString("settings.system.empty-tag.name", "&7None");
      if (activeSlotCat >= 0) {
         ModalItem activeButton = ItemBuilder.from(Material.NAME_TAG)
            .name(this.buildNavButtonTitle("active-tag", Map.of("tag", activeName)))
            .asModalItem()
            .enchant();
         modal.setItem(activeSlotCat, activeButton);
      }

      boolean topCat = this.defaultView.equals("category");
      int backSlot;
      if (this.swapGlobal && topCat) {
         backSlot = this.plugin.getConfig().getInt("settings.gui.layout.items.close-button-slot-category", -1);
         if (backSlot >= 0) {
            ModalItem closeButton = ItemBuilder.from(Material.BARRIER)
               .name(this.buildNavButtonTitle("close-button", Map.of()))
               .asModalItem(event -> {
                  this.handleTopClose((Player) event.getWhoClicked());
               });
            modal.setItem(backSlot, closeButton);
         }
      } else {
         backSlot = this.plugin.getConfig().getInt("settings.gui.layout.items.back-button-slot-category", -1);
         if (backSlot >= 0) {
            ModalItem backButton = ItemBuilder.from(Material.SPECTRAL_ARROW)
               .name(this.buildNavButtonTitle("back-button", Map.of()))
               .asModalItem(event -> {
                  this.handleTopClose((Player) event.getWhoClicked());
               });
            modal.setItem(backSlot, backButton);
         }
      }
   }

   private void addTagsNavigationButtons(PaginatedModal modal, Player player, GuiSession session) {
      ModalItem prevButton = ItemBuilder.from(Material.ARROW)
         .name(this.buildNavButtonTitle("last-page-button", Map.of()))
         .asModalItem(event -> {
            if (modal.previous()) {
               // Page changed successfully
            }
         });
      modal.setItem(this.prevBtn.slot, prevButton);

      ModalItem nextButton = ItemBuilder.from(Material.ARROW)
         .name(this.buildNavButtonTitle("next-page-button", Map.of()))
         .asModalItem(event -> {
            if (modal.next()) {
               // Page changed successfully
            }
         });
      modal.setItem(this.nextBtn.slot, nextButton);

      Component categoryButtonName = this.categoryButtonName(session.filter);
      ModalItem categoryButton = ItemBuilder.from(Material.GOLD_BLOCK)
         .name(categoryButtonName)
         .asModalItem(event -> {
            ClickType clickType = event.getClick();
            if (clickType == ClickType.RIGHT) {
               session.filter = this.prevFilter(player, session.filter);
            } else {
               session.filter = this.nextFilter(player, session.filter);
            }
            
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               this.openTagsGui(player, null, 0);
            });
         });
      modal.setItem(this.catBtn.slot, categoryButton);

      ModalItem favButton = ItemBuilder.from(Material.NETHER_STAR)
         .name(this.favoriteButtonName(session.sort))
         .asModalItem(event -> {
            session.sort = session.sort == ModalProcessor.Sort.UNSORTED ? ModalProcessor.Sort.SORTED : ModalProcessor.Sort.UNSORTED;
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               this.openTagsGui(player, null, -999);
            });
         });
      modal.setItem(this.favBtn.slot, favButton);

      if (this.plugin.getConfig().getBoolean("settings.gui.layout.items.color-sort-button", false)) {
         String colorKey = session.colorFilter.toLowerCase(Locale.ROOT);
         Material matToUse = this.colorSwitchMaterial ? this.getColorMaterial(colorKey) : this.mat("color-sort-button-material");
         
         ModalItem colorButton = ItemBuilder.from(matToUse)
            .name(this.buildNavButtonTitle("color-sort-button", Map.of()))
            .asModalItem(event -> {
               if (event.getClick() == ClickType.RIGHT) {
                  session.colorFilter = this.prevColor(session.colorFilter);
               } else {
                  session.colorFilter = this.nextColor(session.colorFilter);
               }

               Bukkit.getScheduler().runTask(this.plugin, () -> {
                  this.openTagsGui(player, null, session.page);
               });
            });
         modal.setItem(this.colorSortBtn.slot, colorButton);
      }

      ModalItem resetButton = ItemBuilder.from(Material.RED_DYE)
         .name(this.buildNavButtonTitle("reset-button", Map.of()))
         .asModalItem(event -> {
            Player p = (Player) event.getWhoClicked();
            this.data.setActive(p.getUniqueId(), "none");
            String message = this.plugin.getConfig().getString("settings.messages.tag-reset", "");
            Component parsedMessage = TextUtility.parse(message);
            this.plugin.adventure().sender(p).sendMessage(parsedMessage);
            
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               this.openTagsGui(p, null, -999);
            });
         });
      modal.setItem(this.resetBtn.slot, resetButton);

      String aId = this.data.get(player.getUniqueId()).active;
      String aName = aId != null && !aId.equalsIgnoreCase("none") && !this.tags.byId(aId).isEmpty() ? LEGACY.serialize(((TagModal.Tag)this.tags.byId(aId).get()).name()) : this.tagCfg.getString("settings.system.empty-tag.name", "&7None");
      ModalItem activeButton = ItemBuilder.from(Material.NAME_TAG)
         .name(this.buildNavButtonTitle("active-tag", Map.of("tag", aName)))
         .asModalItem()
         .enchant();
      modal.setItem(this.activeBtn.slot, activeButton);

      boolean topTags = this.defaultView.equals("tags");
      if (this.swapGlobal && topTags) {
         ModalItem closeButton = ItemBuilder.from(Material.BARRIER)
            .name(this.buildNavButtonTitle("close-button", Map.of()))
            .asModalItem(event -> {
               this.handleTopClose((Player) event.getWhoClicked());
            });
         modal.setItem(this.backBtn.slot, closeButton);
      } else {
         ModalItem closeButton = ItemBuilder.from(Material.BARRIER)
            .name(this.buildNavButtonTitle("close-button", Map.of()))
            .asModalItem(event -> {
               this.handleTopClose((Player) event.getWhoClicked());
            });
         modal.setItem(this.closeBtn.slot, closeButton);
         
         ModalItem backButton = ItemBuilder.from(Material.SPECTRAL_ARROW)
            .name(this.buildNavButtonTitle("back-button", Map.of()))
            .asModalItem(event -> {
               Bukkit.getScheduler().runTask(this.plugin, () -> {
                  this.openCategoryGui((Player) event.getWhoClicked());
               });
            });
         modal.setItem(this.backBtn.slot, backButton);
      }
   }

   private ModalItem buildTagItem(Player player, TagModal.Tag tag) {
      PlayerDataModule.PlayerData pd = this.data.get(player.getUniqueId());
      boolean unlocked = pd.unlocked.contains(tag.id()) || tag.cost() == 0 || !this.eco.active();
      boolean hasPerm = player.hasPermission(tag.permission());
      ConfigModule.GameState st;
      if (!hasPerm) {
         st = ConfigModule.GameState.PROTECTED;
      } else if (tag.id().equals(pd.active)) {
         st = ConfigModule.GameState.ACTIVE;
      } else if (unlocked) {
         st = ConfigModule.GameState.UNLOCKED;
      } else {
         st = ConfigModule.GameState.LOCKED;
      }

      String base = "settings.gui.tags.tag-items.";
      String lorePath;
      switch(st) {
      case ACTIVE:
         lorePath = base + "active-lore";
         break;
      case LOCKED:
         lorePath = base + "locked-lore";
         break;
      case UNLOCKED:
         lorePath = base + "unlocked-lore";
         break;
      default:
         lorePath = base + "protected-lore";
      }

      boolean fav = pd.favorites.contains(tag.id());
      String fmsg = this.tagCfg.getString("settings.system.favorite.msg." + (fav ? "remove" : "add"), "");
      String fstate = this.tagCfg.getString("settings.system.favorite.state." + (fav ? "enabled" : "disabled"), "");
      List<String> tmpl = this.plugin.getConfig().getStringList(lorePath);
      List<Component> lore = new ArrayList();
      Iterator var13 = tmpl.iterator();

      while(var13.hasNext()) {
         String line = (String)var13.next();
         String repl = line.replace("{display}", LEGACY.serialize(tag.display())).replace("{cost}", String.valueOf(tag.cost())).replace("{status}", this.tags.statusText(st)).replace("{favoritemsg}", fmsg).replace("{favoritestate}", fstate);
         if (repl.contains("{description}")) {
            String[] ps = repl.split("\\{description\\}", -1);
            Component before = LEGACY.deserialize("&r&f" + ps[0]).decoration(TextDecoration.ITALIC, false);
            Component after = ps.length > 1 ? LEGACY.deserialize("&r&f" + ps[1]).decoration(TextDecoration.ITALIC, false) : Component.empty();
            Iterator var19 = tag.description().iterator();

            while(var19.hasNext()) {
               Component desc = (Component)var19.next();
               lore.add(((TextComponent)((TextComponent)Component.empty().append(before)).append(desc.decoration(TextDecoration.ITALIC, false))).append((Component)after));
            }
         } else {
            lore.add(LEGACY.deserialize("&r&f" + repl).decoration(TextDecoration.ITALIC, false));
         }
      }

      Material mat = fav ? this.mat("favorite-tag-material") : tag.icon();
      ItemBuilder itemBuilder = ItemBuilder.from(mat)
         .name(LEGACY.deserialize("&r&f" + LEGACY.serialize(tag.name())).decoration(TextDecoration.ITALIC, false))
         .lore(lore);

      if (fav) {
         int cmd = this.plugin.getConfig().getInt("settings.gui.layout.materials.favorite-tag-material.custom-model-data", 0);
         itemBuilder.modelData(cmd);
      }

      if (fav && this.tagCfg.getBoolean("settings.system.favorite.icon.enabled", false)) {
         Component star = LEGACY.deserialize(this.tagCfg.getString("settings.system.favorite.icon.name", "")).decoration(TextDecoration.ITALIC, false);
         Component name = ((TextComponent)Component.empty().append(LEGACY.deserialize("&r&f" + LEGACY.serialize(tag.name())).decoration(TextDecoration.ITALIC, false))).append(star);
         itemBuilder.name(name);
      }

      if (st == ConfigModule.GameState.ACTIVE && this.plugin.getConfig().getBoolean("settings.system.active-tag-glow", true)) {
         itemBuilder.enchant();
      }

      return itemBuilder.asModalItem(event -> {
         this.handleTagClick((Player) event.getWhoClicked(), tag, event.getClick());
      });
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onClick(InventoryClickEvent e) {
      UUID uuid = e.getWhoClicked().getUniqueId();
      ModalProcessor.GuiSession s = (ModalProcessor.GuiSession)this.open.get(uuid);
      if (s != null) {
         e.setCancelled(true);
         // Let the modal system handle the click
      }
   }

   @EventHandler(priority = EventPriority.HIGHEST)
   public void onDrag(InventoryDragEvent e) {
      if (this.open.containsKey(e.getWhoClicked().getUniqueId())) {
         e.setCancelled(true);
      }
   }

   @EventHandler
   public void onClose(InventoryCloseEvent e) {
      this.open.remove(e.getPlayer().getUniqueId());
   }

   private List<TagModal.Tag> applyFilterAndSort(Player p, ModalProcessor.GuiSession s) {
      String filter = s.filter.toUpperCase(Locale.ROOT);
      List<TagModal.Tag> src;
      
      switch(filter) {
         case "ALL":
            src = this.accessibleTags(p);
            break;
         case "FAVORITES":
            src = this.accessibleTags(p).stream().filter((t) -> {
               return this.data.get(p.getUniqueId()).favorites.contains(t.id());
            }).toList();
            break;
         case "UNLOCKED":
            src = this.accessibleTags(p).stream().filter((t) -> {
               return this.data.get(p.getUniqueId()).unlocked.contains(t.id()) || t.cost() == 0 || !this.eco.active();
            }).toList();
            break;
         case "LOCKED":
            src = this.accessibleTags(p).stream().filter((t) -> {
               return !this.data.get(p.getUniqueId()).unlocked.contains(t.id()) && t.cost() != 0 && this.eco.active();
            }).toList();
            break;
         case "PROTECTED":
            src = this.cats.all().stream().filter(CategoryModal.TagCategory::isProtected).flatMap((c) -> {
               return this.tags.byCategory(c.key()).stream();
            }).toList();
            break;
         default:
            src = this.tags.byCategory(s.filter);
      }

      if (!s.colorFilter.equalsIgnoreCase("ALL")) {
         String cf = s.colorFilter.equals("GREY") ? "GRAY" : s.colorFilter;
         src = src.stream().filter((tag) -> {
            return tag.color().equalsIgnoreCase(cf);
         }).toList();
      }

      if (s.sort == ModalProcessor.Sort.SORTED) {
         Set<String> favs = this.data.get(p.getUniqueId()).favorites;
         src = (List)src.stream().map((o) -> {
            return o;
         }).sorted(Comparator.comparing((t) -> {
            return !favs.contains(t.id());
         }).thenComparing((t) -> {
            return PLAIN.serialize(t.name());
         }, String.CASE_INSENSITIVE_ORDER)).collect(Collectors.toList());
      }

      return src;
   }

   private List<TagModal.Tag> accessibleTags(Player p) {
      return (List)this.cats.all().stream().filter((c) -> {
         return p.hasPermission(c.permission());
      }).sorted(Comparator.comparingInt(CategoryModal.TagCategory::slot)).flatMap((c) -> {
         return this.tags.byCategory(c.key()).stream();
      }).collect(Collectors.toList());
   }

   private List<String> filterOrder(Player p) {
      List<String> order = new ArrayList();
      ConfigurationSection fs = this.catCfg.getConfigurationSection("settings.system.category-sort.filters");
      Iterator var4;
      String id;
      if (fs != null) {
         var4 = fs.getKeys(false).iterator();

         while(var4.hasNext()) {
            String key = (String)var4.next();
            id = fs.getString(key + ".id", key).toUpperCase(Locale.ROOT);
            order.add(id);
         }
      }

      var4 = this.cats.all().iterator();

      while(var4.hasNext()) {
         CategoryModal.TagCategory c = (CategoryModal.TagCategory)var4.next();
         id = c.key().toUpperCase(Locale.ROOT);
         if (!order.contains(id) && p.hasPermission(c.permission())) {
            order.add(id);
         }
      }

      return order;
   }

   private String nextFilter(Player p, String cur) {
      List<String> order = this.filterOrder(p);
      int idx = order.indexOf(cur.toUpperCase(Locale.ROOT));
      if (idx < 0) {
         idx = 0;
      }

      return (String)order.get((idx + 1) % order.size());
   }

   private String prevFilter(Player p, String cur) {
      List<String> order = this.filterOrder(p);
      int idx = order.indexOf(cur.toUpperCase(Locale.ROOT));
      if (idx < 0) {
         idx = 0;
      }

      return (String)order.get((idx - 1 + order.size()) % order.size());
   }

   private Component categoryButtonName(String filterKey) {
      String base = "settings.system.category-sort.";
      String pat = this.catCfg.getString(base + "sort-button.name", "&7CATEGORY &8• {filter}");
      String name = this.catCfg.getString(base + "filters." + filterKey.toLowerCase(Locale.ROOT) + ".name", filterKey);
      return LEGACY.deserialize(pat.replace("{filter}", name));
   }

   private Component favoriteButtonName(ModalProcessor.Sort sort) {
      String base = "settings.system.favorites-sort.";
      String pat = this.catCfg.getString(base + "sort-button.name", "&7FAVORITES &8• {sort-type}");
      String key = sort.name().toLowerCase(Locale.ROOT);
      String name = this.catCfg.getString(base + "sort-type." + key + ".name", sort.name());
      return LEGACY.deserialize(pat.replace("{sort-type}", name));
   }

   private void handleTopClose(Player p) {
      if (this.closeCfg.enabled()) {
         if (this.closeCfg.closeGuiFirst()) {
            p.closeInventory();
            Bukkit.getScheduler().runTask(this.plugin, () -> {
               this.runCloseCommands(p);
            });
         } else {
            this.runCloseCommands(p);
            p.closeInventory();
         }
      } else {
         p.closeInventory();
      }
   }

   private void runCloseCommands(Player p) {
      Iterator var2 = this.closeCfg.commands().iterator();

      while(var2.hasNext()) {
         String cmd = (String)var2.next();
         if (cmd != null && !cmd.isBlank()) {
            String c = cmd.replace("%player%", p.getName());
            if (this.closeCfg.runAsConsole()) {
               this.plugin.getServer().dispatchCommand(this.plugin.getServer().getConsoleSender(), c);
            } else {
               this.plugin.getServer().dispatchCommand(p, c);
            }
         }
      }
   }

   private Component buildNavButtonTitle(String key, Map<String, String> vars) {
      String titlePath = "settings.gui.layout.titles." + key + "-name";
      String rawTitle = this.plugin.getConfig().getString(titlePath, "");

      for(Entry<String, String> e : vars.entrySet()) {
         rawTitle = rawTitle.replace("{" + e.getKey() + "}", e.getValue());
      }

      return LEGACY.deserialize("&r&f" + rawTitle).decoration(TextDecoration.ITALIC, false);
   }

   private Set<Integer> parseSlots(List<?> raw) {
      Set<Integer> out = new HashSet();
      Iterator var3 = raw.iterator();

      while(true) {
         while(var3.hasNext()) {
            Object o = var3.next();
            String t = o.toString().trim();
            if (t.contains("..")) {
               String[] ps = t.split("\\.\\.");

               try {
                  int s = Integer.parseInt(ps[0]);
                  int e = Integer.parseInt(ps[1]);

                  for(int i = s; i <= e; ++i) {
                     out.add(i);
                  }
               } catch (Exception var11) {
               }
            } else {
               try {
                  out.add(Integer.parseInt(t));
               } catch (Exception var10) {
               }
            }
         }

         return out;
      }
   }

   private void fillEmptySlots(Inventory inv, String guiKey) {
      ConfigurationSection sec = this.plugin.getConfig().getConfigurationSection("settings.gui.layout.items.empty-slot-item." + guiKey);
      if (sec != null && sec.getBoolean("enabled", false)) {
         List<?> raw = sec.getList("slots", List.of());
         Set<Integer> slots = this.parseSlots(raw);
         ItemStack filler = new ItemStack(this.mat("empty-slot-material"));
         ItemMeta meta = filler.getItemMeta();
         String rawName = this.plugin.getConfig().getString("settings.gui.layout.titles.empty-slot-name", "");
         meta.displayName(LEGACY.deserialize("&r&f" + rawName).decoration(TextDecoration.ITALIC, false));
         boolean glint = this.plugin.getConfig().getBoolean("settings.gui.layout.materials.empty-slot-material.enchantment-glint", false);
         if (glint) {
            meta.addEnchant(Enchantment.UNBREAKING, 1, true);
            meta.addItemFlags(new ItemFlag[]{ItemFlag.HIDE_ENCHANTS});
         }

         filler.setItemMeta(meta);
         Iterator var10 = slots.iterator();

         while(var10.hasNext()) {
            int slot = (Integer)var10.next();
            if (slot >= 0 && slot < inv.getSize()) {
               inv.setItem(slot, filler);
            }
         }
      }
   }

   private void handleTagClick(Player p, TagModal.Tag tag, ClickType click) {
      PlayerDataModule.PlayerData pd = this.data.get(p.getUniqueId());
      boolean unlocked = pd.unlocked.contains(tag.id()) || tag.cost() == 0 || !this.eco.active();
      switch(click) {
      case LEFT:
         String message;
         if (unlocked) {
            this.data.setActive(p.getUniqueId(), tag.id());
            message = this.plugin.getConfig().getString("settings.messages.tag-activate", "");
            message = message.replace("{activetag}", PLAIN.serialize(tag.name()));
            message = message.replace("{tagdisplay}", PLAIN.serialize(tag.display()));
            message = this.replaceConditionPlaceholders(message);
            this.plugin.adventure().sender(p).sendMessage(this.formatMessage(message));
         } else {
            message = this.plugin.getConfig().getString("settings.messages.tag-locked", "");
            message = message.replace("{tag}", PLAIN.serialize(tag.name()));
            message = this.replaceConditionPlaceholders(message);
            this.plugin.adventure().sender(p).sendMessage(this.formatMessage(message));
         }
         break;
      case SHIFT_LEFT:
         if (!unlocked) {
            this.attemptPurchase(p, tag);
         }
         break;
      case RIGHT:
         this.data.toggleFavorite(p.getUniqueId(), tag.id());
         break;
      case MIDDLE:
         this.data.toggleFavorite(p.getUniqueId(), tag.id());
         if (unlocked) {
            this.data.setActive(p.getUniqueId(), tag.id());
         }
      }

      Bukkit.getScheduler().runTask(this.plugin, () -> {
         this.openTagsGui(p, null, -999);
      });
   }

   private void attemptPurchase(Player p, TagModal.Tag tag) {
      double cost = (double)tag.cost();
      if (!this.eco.canAfford(p, cost)) {
         String message = this.plugin.getConfig().getString("settings.messages.tag-balance", "&cInsufficient funds. &7You need &c{cost} &7to unlock the {tag} &7tag.").replace("{cost}", String.valueOf(cost)).replace("{tag}", PLAIN.serialize(tag.name()));
         this.plugin.adventure().sender(p).sendMessage(LEGACY.deserialize(message));
      } else {
         this.eco.withdraw(p, cost);
         this.data.unlockTag(p.getUniqueId(), tag.id());
         String message = this.plugin.getConfig().getString("settings.messages.tag-unlocked", "").replace("{cost}", String.valueOf(cost)).replace("{tag}", PLAIN.serialize(tag.name()));
         this.plugin.adventure().sender(p).sendMessage(LEGACY.deserialize(message));
      }
   }

   private Material mat(String key) {
      String base = "settings.gui.layout.materials.";
      ConfigurationSection sec = this.plugin.getConfig().getConfigurationSection(base + key);
      if (sec == null) {
         this.plugin.getLogger().warning("[CoreTags] Missing config for '" + base + key + "'");
         return Material.STONE;
      } else {
         String raw = sec.getString("material");

         try {
            return Material.valueOf(raw.toUpperCase(Locale.ROOT));
         } catch (Exception var6) {
            this.plugin.getLogger().warning("[CoreTags] Invalid material '" + raw + "' at '" + base + key + "'");
            return Material.STONE;
         }
      }
   }

   private Material getColorMaterial(String colorKey) {
      String colorBase = "settings.gui.layout.materials.color-sort-button-switch-material.material." + colorKey + ".";
      if (!this.plugin.getConfig().contains(colorBase + "material")) {
         this.plugin.getLogger().warning("[CoreTags] Missing config for '" + colorBase + "material'");
         return Material.BRUSH;
      }

      String matName = this.plugin.getConfig().getString(colorBase + "material", "BRUSH").toUpperCase(Locale.ROOT);
      try {
         return Material.valueOf(matName);
      } catch (Exception e) {
         this.plugin.getLogger().warning("[CoreTags] Invalid material '" + matName + "' at '" + colorBase + "material'");
         return Material.BRUSH;
      }
   }

   private int slot(String path) {
      return this.plugin.getConfig().getInt(path, 0);
   }

   private String nextColor(String cur) {
      int i = COLORS.indexOf(cur.toUpperCase(Locale.ROOT));
      if (i < 0) {
         i = 0;
      }

      return (String)COLORS.get((i + 1) % COLORS.size());
   }

   private String prevColor(String cur) {
      int i = COLORS.indexOf(cur.toUpperCase(Locale.ROOT));
      if (i < 0) {
         i = 0;
      }

      return (String)COLORS.get((i - 1 + COLORS.size()) % COLORS.size());
   }

   private String replaceConditionPlaceholders(String message) {
      ConfigurationSection conditionSection = this.plugin.getConfig().getConfigurationSection("settings.system.conditions");
      String key;
      String conditionText;
      if (conditionSection != null) {
         for(Iterator var3 = conditionSection.getKeys(false).iterator(); var3.hasNext(); message = message.replace("{" + key + "}", conditionText)) {
            key = (String)var3.next();
            conditionText = conditionSection.getString(key + ".text", "");
         }
      }

      return message;
   }

   private Component formatMessage(String message) {
      if (message.contains("<") && message.contains(">")) {
         return MiniMessage.miniMessage().deserialize(message);
      } else {
         return !message.contains("&") && !message.contains("§") ? Component.text(message) : LegacyComponentSerializer.builder().hexColors().build().deserialize(message);
      }
   }

   private static record Btn(Material mat, int slot) {
      private Btn(Material mat, int slot) {
         this.mat = mat;
         this.slot = slot;
      }

      public Material mat() {
         return this.mat;
      }

      public int slot() {
         return this.slot;
      }
   }

   private static enum Sort {
      UNSORTED,
      SORTED;

      private static ModalProcessor.Sort[] $values() {
         return new ModalProcessor.Sort[]{UNSORTED, SORTED};
      }
   }

   private static final class GuiSession {
      ModalProcessor.GuiType type;
      int page;
      String filter;
      ModalProcessor.Sort sort;
      String colorFilter;

      GuiSession(ModalProcessor.GuiType t, int p, String f, ModalProcessor.Sort s, String c) {
         this.type = t;
         this.page = p;
         this.filter = f;
         this.sort = s;
         this.colorFilter = c;
      }
   }

   private static enum GuiType {
      CATEGORY,
      TAGS;

      private static ModalProcessor.GuiType[] $values() {
         return new ModalProcessor.GuiType[]{CATEGORY, TAGS};
      }
   }
}